#include <iostream>
using namespace std;

class Stack {
private:
    int arr[100];
    int top;
public:
    Stack() : top(-1) {}
    void push(int val) {
        if (top >= 99) return;
        arr[++top] = val;
        cout << "OK\n";
    }
    int pop() {
        if (top < 0) return -1;
        return arr[top--];
    }
    // no peek, isEmpty, size — incomplete, should be different
};
