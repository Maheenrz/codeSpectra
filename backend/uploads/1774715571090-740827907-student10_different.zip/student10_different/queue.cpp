#include <iostream>
using namespace std;

class Queue {
private:
    int arr[100];
    int front, rear;
public:
    Queue() : front(0), rear(-1) {}
    void enqueue(int val) {
        if (rear >= 99) return;
        arr[++rear] = val;
        cout << "OK\n";
    }
    int dequeue() {
        if (front > rear) return -1;
        return arr[front++];
    }
    // missing front, isEmpty, size
};
